define({
  "serviceURL": "adresa URL služby",
  "defaultTitle": "Výchozí název",
  "defaultAuthor": "Výchozí autor",
  "defaultCopyright": "Výchozí autorská práva",
  "defaultFormat": "Výchozí formát",
  "defaultLayout": "Výchozí rozvržení",
  "warning": "Nesprávný vstup",
  "urlNotAvailable": "Adresa URL není k dispozici.",
  "notPrintTask": "Adresa URL neodkazuje na tiskovou úlohu.",
  "advancedOption": "Zobrazit pokročilé možnosti",
  "ok": "OK",
  "editable": "Editovatelné"
});