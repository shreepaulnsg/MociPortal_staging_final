define({
  "serviceURL": "URL υπηρεσίας",
  "defaultTitle": "Προεπιλεγμένος τίτλος",
  "defaultAuthor": "Προεπιλεγμένος συντάκτης",
  "defaultCopyright": "Προεπιλογή πνευματικών δικαιωμάτων",
  "defaultFormat": "Προεπιλεγμένη μορφή",
  "defaultLayout": "Προεπιλεγμένη διάταξη",
  "warning": "Εσφαλμένη είσοδος στοιχείων",
  "urlNotAvailable": "Το url δεν είναι διαθέσιμο",
  "notPrintTask": "Το url δεν είναι εργασία εκτύπωσης",
  "advancedOption": "Εμφάνιση επιλογών για προχωρημένους",
  "ok": "ΟΚ",
  "editable": "Επεξεργάσιμο"
});