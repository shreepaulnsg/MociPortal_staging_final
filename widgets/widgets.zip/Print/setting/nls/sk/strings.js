define({
  "serviceURL": "URL adresa služby",
  "defaultTitle": "Predvolený názov",
  "defaultAuthor": "Predvolený autor",
  "defaultCopyright": "Predvolené autorské právo",
  "defaultFormat": "Predvolený formát",
  "defaultLayout": "Predvolené rozloženie",
  "warning": "Nesprávny vstup",
  "urlNotAvailable": "url adresa nie je dostupná",
  "notPrintTask": "url adresa nie je tlačová úloha",
  "advancedOption": "Zobraziť rozšírené možnosti",
  "ok": "OK",
  "editable": "Editovateľný"
});