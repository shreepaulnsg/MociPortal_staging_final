define({
  "serviceURL": "URL сервісу",
  "defaultTitle": "Заголовок за замовчуванням",
  "defaultAuthor": "Автор за замовчуванням",
  "defaultCopyright": "Авторське право за змовчуванням",
  "defaultFormat": "Формат за замовчуванням",
  "defaultLayout": "Компонування за замовчуванням",
  "warning": "Некоректне введення",
  "urlNotAvailable": "URL недоступний",
  "notPrintTask": "URL не є задачею друку",
  "advancedOption": "Показати розширені опції",
  "ok": "OK",
  "editable": "Редагований"
});