define({
  "serviceURL": "URL servisa",
  "defaultTitle": "Podrazumevani naslov",
  "defaultAuthor": "Podrazumevani autor",
  "defaultCopyright": "Podrazumevano autorsko pravo",
  "defaultFormat": "Podrazumevani format",
  "defaultLayout": "Podrazumevani raspored",
  "warning": "Netačan unos",
  "urlNotAvailable": "URL adresa nije dostupna",
  "notPrintTask": "URL adresa nije zadatak za štampanje",
  "advancedOption": "Prikaži napredne opcije",
  "ok": "U redu",
  "editable": "Može da se izmeni"
});