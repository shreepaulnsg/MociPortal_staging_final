define({
  "serviceURL": "Palvelun URL",
  "defaultTitle": "Oletusotsikko",
  "defaultAuthor": "Oletustekijä",
  "defaultCopyright": "Oletustekijänoikeus",
  "defaultFormat": "Oletusmuoto",
  "defaultLayout": "Oletusasettelu",
  "warning": "Virheellinen lähtöaineisto",
  "urlNotAvailable": "URL-osoite ei ole käytettävissä",
  "notPrintTask": "URL-osoite ei ole tulostustyö",
  "advancedOption": "Näytä lisäasetukset",
  "ok": "OK",
  "editable": "Muokattavissa"
});