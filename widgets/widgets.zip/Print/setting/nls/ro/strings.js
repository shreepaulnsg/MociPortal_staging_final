define({
  "serviceURL": "URL serviciu",
  "defaultTitle": "Titlu implicit",
  "defaultAuthor": "Autor implicit",
  "defaultCopyright": "Drepturi de autor implicite",
  "defaultFormat": "Format implicit",
  "defaultLayout": "Aspect implicit",
  "warning": "Intrare incorectă",
  "urlNotAvailable": "URL-ul nu este disponibil",
  "notPrintTask": "URL-ul nu este o activitate de imprimare",
  "advancedOption": "Afişare opţiuni avansate",
  "ok": "OK",
  "editable": "Editabil"
});