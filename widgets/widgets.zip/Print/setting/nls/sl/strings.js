define({
  "serviceURL": "URL storitve",
  "defaultTitle": "Privzeti naslov",
  "defaultAuthor": "Privzeti avtor",
  "defaultCopyright": "Privzete avtorske pravice",
  "defaultFormat": "Privzeti format",
  "defaultLayout": "Privzeta postavitev",
  "warning": "Nepravilen vnos",
  "urlNotAvailable": "Url ni na voljo",
  "notPrintTask": "Url ni naloga tiskanja",
  "advancedOption": "Pokaži napredne možnosti",
  "ok": "V redu",
  "editable": "Uredljiv"
});