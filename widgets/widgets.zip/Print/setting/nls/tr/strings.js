define({
  "serviceURL": "Servis URL'si",
  "defaultTitle": "Varsayılan başlık",
  "defaultAuthor": "Varsayılan yazar",
  "defaultCopyright": "Varsayılan telif hakkı",
  "defaultFormat": "Varsayılan biçim",
  "defaultLayout": "Varsayılan düzen",
  "warning": "Hatalı girdi",
  "urlNotAvailable": "Url kullanılamıyor",
  "notPrintTask": "Url bir baskı görevi değil",
  "advancedOption": "Gelişmiş seçenekleri göster",
  "ok": "Tamam",
  "editable": "Düzenlenebilir"
});