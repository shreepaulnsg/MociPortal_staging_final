define({
  "serviceURL": "خدمة عنوان URL",
  "defaultTitle": "العنوان الافتراضي",
  "defaultAuthor": "المؤلف الافتراضي",
  "defaultCopyright": "حقوق نشر افتراضية",
  "defaultFormat": "تنسيق افتراضي",
  "defaultLayout": "تخطيط افتراضي",
  "warning": "مدخلات غير صحيحة",
  "urlNotAvailable": "لا يتوفر عنوان url",
  "notPrintTask": "عنوان url ليس مهمة طباعة",
  "advancedOption": "عرض الخيارات المتقدمة",
  "ok": "موافق",
  "editable": "قابل للتحرير"
});