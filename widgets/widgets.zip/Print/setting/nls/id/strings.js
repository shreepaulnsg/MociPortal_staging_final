define({
  "serviceURL": "URL Layanan",
  "defaultTitle": "Judul default",
  "defaultAuthor": "Penulis default",
  "defaultCopyright": "Hak cipta default",
  "defaultFormat": "Format default",
  "defaultLayout": "Tata letak default",
  "warning": "Input salah",
  "urlNotAvailable": "Url tidak tersedia",
  "notPrintTask": "Url bukan tugas cetak",
  "advancedOption": "Tampilkan opsi lanjutan",
  "ok": "Ya",
  "editable": "Dapat Diedit"
});