define({
  "serviceURL": "서비스 URL",
  "defaultTitle": "기본 제목",
  "defaultAuthor": "기본 작성자",
  "defaultCopyright": "기본 저작권",
  "defaultFormat": "기본 형식",
  "defaultLayout": "기본 레이아웃",
  "warning": "잘못된 입력",
  "urlNotAvailable": "URL을 사용할 수 없습니다.",
  "notPrintTask": "이 URL은 인쇄 작업이 아닙니다.",
  "advancedOption": "고급 옵션 보기",
  "ok": "확인",
  "editable": "편집 가능"
});