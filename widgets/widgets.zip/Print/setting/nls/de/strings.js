define({
  "serviceURL": "Service-URL",
  "defaultTitle": "Standardtitel",
  "defaultAuthor": "Standardverfasser",
  "defaultCopyright": "Standard-Copyright",
  "defaultFormat": "Standardformat",
  "defaultLayout": "Standard-Layout",
  "warning": "Falsche Eingabe",
  "urlNotAvailable": "Die URL ist nicht verfügbar",
  "notPrintTask": "Die URL ist kein Druck-Task",
  "advancedOption": "Erweiterte Optionen anzeigen",
  "ok": "OK",
  "editable": "Editierbar"
});