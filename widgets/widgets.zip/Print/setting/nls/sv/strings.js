define({
  "serviceURL": "Tjänste-URL",
  "defaultTitle": "Standardtitel",
  "defaultAuthor": "Standardförfattare",
  "defaultCopyright": "Standardcopyright",
  "defaultFormat": "Standardformat",
  "defaultLayout": "Standardlayout",
  "warning": "Felaktiga indata",
  "urlNotAvailable": "Webbadressen är inte tillgänglig.",
  "notPrintTask": "Webbadressen är inte en utskriftsåtgärd",
  "advancedOption": "Visa avancerade alternativ",
  "ok": "OK",
  "editable": "Redigerbar"
});