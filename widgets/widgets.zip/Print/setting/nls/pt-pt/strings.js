define({
  "serviceURL": "URL de Serviço",
  "defaultTitle": "Título predefinido",
  "defaultAuthor": "Autor predefinido",
  "defaultCopyright": "Copyright predefinido",
  "defaultFormat": "Formato predefinido",
  "defaultLayout": "Layout predefinido",
  "warning": "Entrada incorreta",
  "urlNotAvailable": "O url não se encontra disponível",
  "notPrintTask": "O url não é uma tarefa de impressão",
  "advancedOption": "Mostrar opções avançadas",
  "ok": "OK",
  "editable": "Editável"
});