define({
  "serviceURL": "URL Dịch vụ",
  "defaultTitle": "Tiêu đề mặc định",
  "defaultAuthor": "Tác giả mặc định",
  "defaultCopyright": "Bản quyền mặc định",
  "defaultFormat": "Định dạng mặc định",
  "defaultLayout": "Bố cục mặc định",
  "warning": "Đầu vào không đúng",
  "urlNotAvailable": "url không khả dụng",
  "notPrintTask": "url không phải là tác vụ in",
  "advancedOption": "Hiện tùy chọn nâng cao",
  "ok": "OK",
  "editable": "Có thể chỉnh sửa"
});