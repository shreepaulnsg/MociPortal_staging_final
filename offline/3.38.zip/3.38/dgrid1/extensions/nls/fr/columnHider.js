//>>built
define("dgrid1/extensions/nls/fr/columnHider",{popupLabel:"Afficher ou masquer les colonnes"});