//>>built
define("dgrid1/extensions/nls/da/columnHider",{popupLabel:"Vis eller skjul kolonner"});