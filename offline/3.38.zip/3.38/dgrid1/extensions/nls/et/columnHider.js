//>>built
define("dgrid1/extensions/nls/et/columnHider",{popupLabel:"Kuva v\u00f5i peida veerud"});