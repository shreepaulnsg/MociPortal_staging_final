//>>built
define("dijit/form/nls/al/Textarea",{iframeEditTitle:"zona e editimit",iframeFocusTitle:"frame i zon\u00ebs s\u00eb editimit"});