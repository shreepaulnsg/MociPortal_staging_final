//>>built
define("dijit/form/nls/al/ComboBox",{previousMessage:"Zgjedhja e m\u00ebparshme",nextMessage:"M\u00eb tep\u00ebr zgjedhje"});