//>>built
define("dijit/form/nls/vi/Textarea",{iframeEditTitle:"ch\u1ec9nh s\u1eeda khu v\u1ef1c",iframeFocusTitle:"khung ch\u1ec9nh s\u1eeda khu v\u1ef1c"});