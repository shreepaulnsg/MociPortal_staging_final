//>>built
define("dijit/form/nls/lv/ComboBox",{previousMessage:"Iepriek\u0161\u0113j\u0101s izv\u0113les",nextMessage:"Citas izv\u0113les"});