//>>built
define("dijit/form/nls/sl/Textarea",{iframeEditTitle:"urejevalno podro\u010dje",iframeFocusTitle:"okvir urejevalnega podro\u010dja"});