This folder contains skins based on the Dijit themes (claro, tundra, soria, and nihilo),
as well as a number of other skins (e.g. cactus, sage, slate, squid).

The skins are partially based on generic skin elements from the jquery-ui themeroller CSS
convention. The dgrid component follows this convention.

Any other stylesheet based on the themeroller convention can ostensibly
also be used to skin the dgrid.