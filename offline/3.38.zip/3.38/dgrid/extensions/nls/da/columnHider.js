//>>built
define("dgrid/extensions/nls/da/columnHider",{popupLabel:"Vis eller skjul kolonner"});